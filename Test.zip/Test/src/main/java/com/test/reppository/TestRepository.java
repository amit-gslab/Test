package com.test.reppository;

import org.springframework.stereotype.Repository;

@Repository
public interface TestRepository {
}
