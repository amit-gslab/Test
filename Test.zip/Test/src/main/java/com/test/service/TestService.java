package com.test.service;

import com.test.exception.ResourceNotFoundException;
import com.test.models.Test;
import lombok.NonNull;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class TestService {
    private List<Test> test=new ArrayList<>();
    public List<Test> getAll() {
        if(this.test.size()==0) {
            test.add(new Test(1, "Rajesh Agrawal", 200000));
            test.add(new Test(2, "Anil Supe", 500000));
        }
        return test;
    }
    public void savetest(Test test) {
        this.test.add(test);
    }

    public Test getById(int id) {
        List<Test> tests = this.test.stream().filter(i -> i.getId() == id).collect(Collectors.toList());
        return checkLength(tests);
    }

    public Test updateTest(Test test, int id) {
        List<Test> list = this.test.stream().filter(i -> i.getId() == id).collect(Collectors.toList());
        Test test1=null;
        test1 = checkLength(list);
        int i = this.test.indexOf(test1);
        this.test.remove(this.test.indexOf(test1));
        this.test.add(i,test);
        return this.test.get(this.test.indexOf(test));
    }

    public Test deleteTest(int id) {
        List<Test> list = this.test.stream().filter(i -> i.getId() == id).collect(Collectors.toList());
        Test test=null;
        test = checkLength(list);
        Test remove = this.test.remove(this.test.indexOf(test));
        return remove;
    }

    private Test checkLength(List<Test> list){
        if (list.size()==1)
            return list.get(0);
        else
            throw new ResourceNotFoundException();
    }
}
