package com.test.controller;


import com.test.models.Test;
import com.test.service.TestService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class TestController {
    @Autowired
    private TestService testService;
    private String hello;

    @RequestMapping(value = "/hello")
    public String hello(){
        hello = "Hello World";
        hello = hello.concat(" Good Morning");
        return hello;
    }

    @PostMapping(value = "/save")
    public String saveTest(@RequestBody Test test){
        testService.savetest(test);
        return "Test object is added";
    }

    @GetMapping(value = "/test")
    public ResponseEntity<List<Test>> getAll(){
        List<Test> tests = testService.getAll();
        return ResponseEntity.ok(tests);
    }

    @GetMapping(value = "/test/{id}")
    public ResponseEntity<Test> getById(@PathVariable("id") int id){
        Test tests = testService.getById(id);
        return ResponseEntity.ok(tests);
    }

    @PutMapping(value = "/update/{id}")
    public Test updateTest(@RequestBody Test test, @PathVariable("id") int id){
        Test newTest=testService.updateTest(test, id);
        return newTest;
    }

    @DeleteMapping(value = "/delete/{id}")
    public Test deleteTest(@PathVariable("id") int id){
        Test test = testService.deleteTest(id);
        return test;
    }
}
